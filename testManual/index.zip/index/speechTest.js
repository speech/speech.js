'use strict';

describe("Testing", function () {
  it("oneTime", function () {
    (true).should.be.ok;
  });
})