/**
 * TODO: Switch to webworkers when Fx enables indexdb from webworkers
 * TODO: Add WebRTC DHT.
 */

/**
 * Comment out on manual test:
 *  var PouchDB = require
 *  module.exports
 */


'use strict';

//var PouchDB = require('./libs/pouchdb/dist/pouchdb-nightly.min.js'),
//  log = require('./logger'),

  var DEBUG = true,
  log = console;


function DNS(name, url, sync) { //TODO: detect httpS
  var that = this;

  name = name || 'speechis';
  url = url || 'http://api.www.speech.is/speech/';

  this.db = new PouchDB(name, { 'auto_compaction': true});
  this.db.replicate.from(url, {continuous: true}
  ).on('change', function (info) {
      if (sync) sync.change(info);
      if (DEBUG) log.info("change" ,info);
    }).on('complete', function (info) {
      if (sync) sync.complete(info);
      if (DEBUG) log.log("complete", info);
    }).on('error', function (err) {
      if (sync) sync.error(err);
      if (DEBUG) log.error(err);
    });

  this.client = new PouchDB(url);

  /**
   * Equivalent to namecoind name_show d/name or whois on traditional DNS but
   * it assumes '.bit' and it does not support including ANY tld in the query.
   * @param {string} name Domain to lookup, assumes '.bit' tld.
   * @param {function} callback nav.load method for loading websites.
   */
  this.lookup = function(name, callback) {
    /**
     * Check localStorage for cached result
     * @type {Record}
     */
    that.db.get(name, function(err, doc) {
      if (err) {
        that.fetch(name, callback);
      } else {
        callback(null, doc);
      }
    });
  };

  /**
   * Fetches data from remote host
   * TODO: Add multiple hosts, ballistic queries
   * @param {string} name
   * @param {function} callback
   */
  this.fetch = function(name, callback) {
    that.client.get(name, function(err, doc) {
      if (!err) that.save(doc);
      callback(err, doc);
    });
  };

  /**
   * Saves record to appropriate container.
   * @param {Record} r DNS record to be saved.
   * @param {function} callback Function to send response to.
   */
  this.save = function(r, callback) {
    callback = callback || function(m) {log.log(m)};
    r._id = r._id || r.name;

    that.db.get(r.name, function(err, doc) {

      if (!err) {
        r._rev = doc._rev;
        that.db.put(r, callback);
      } else {
        that.db.put(r, callback);
      }
    });

  };

  /**
   * Removes record client storage.
   * @param {string} name Name of DNS record to be removed.
   * @param {function} callback Returns errors or confirmation
   */
  this.delete = function(name, callback) {
    that.db.get(name, function(err, doc) {
      if (err) {
        log.info('error while fetching rev of ' + name + ' for deletion.', err);
      } else {
        that.db.remove(doc, function(err, response) {
          if (err) {
            log.warn('Unable to delete ' + name + ' ', err);
          }
          if (response) {
            log.log(response);
          }
        });
      }
    });
  };


  /**
   * Utility function for creating new DBS object with independent connections
   * @return {function} New DNS object.
   */
  this.init = function(name, url, sync) {
    return new DNS(name, url, sync);
  };

}

//module.exports = new DNS();
window.dns = DNS;


/**
 * A number, or a string containing a number.
 * @typedef {Object} Record
 * @property {string} name Name of record
 * @property {string} _id PouchDB compatible alias of name param.
 * @property {Http} value Value which contains an http transport with either a FQDN or IPv4 address.
 * @property {string} _rev CouchDB/PouchDB revision string.
 * */


/**
 * A number, or a string containing a number.
 * @typedef {Object} Http value.
 * @property {string} http FQDN or IPv4 address. *
 * */
